```{r}
library(tidyverse)
library(ggplot2)
install.packages("ggmap")
library(ggmap)
library(scales)

unicef_indicator_1 <- read.csv("unicef_indicator_1.csv")

unicef_metadata <- read.csv("unicef_metadata.csv")

merged_data <- merge(unicef_indicator_1, unicef_metadata, by = "country")

library(ggplot2)

ggplot(merged_data, aes(x = year, y = obs_value)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Income Ratios vs. Health Services Coverage",
       x = "Income Ratio",
       y = "Coverage of Essential Health Services")
```

```{r}
library(ggplot2)

ggplot(unicef_indicator_1, aes(x = country, y = obs_value )) +
  geom_bar(stat = "identity")

```

```{r}
unicef_indicator_1%>%
  ggplot(aes(time_period,`obs_value`))+
  geom_line()

```

```{r}
library(ggplot2)


```

---
title: "VMIR"
format: html
editor: visual
---

## From this information, we can clearly see that better income ratios lead to better health coverage
